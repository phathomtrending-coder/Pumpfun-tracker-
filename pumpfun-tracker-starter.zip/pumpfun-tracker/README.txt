Pump.fun Tracker Starter Pack

1. Upload this folder to a new GitHub repo named pumpfun-tracker.
2. In Supabase SQL Editor, run sql/supabase_schema.sql.
3. In Render, create a Background Worker from the repo.
4. Set Build Command: pip install -r requirements.txt
5. Set Start Command: python bot.py
6. Add these environment variables in Render:
   BOT_TOKEN=your_telegram_bot_token
   CHANNEL_ID=@your_channel_name
   SUPABASE_URL=https://bjdsgqfvwgtxbssodqoo.supabase.co
   SUPABASE_KEY=your_supabase_secret_key
   SCAN_INTERVAL=30
   MIN_MCAP=1000
   MAX_MCAP=500000
   MIN_VOL_5M=100
   MIN_BUYS_1H=1
7. Make the Telegram bot an admin in your channel.
8. Deploy and watch logs for "scanning..."
